#ifndef LIBINTL_H
#define LIBINTL_H

/* This file is only supposed to be used on systems which doesn't have a
   builtin libintl.h and which also miss gnu gettext */

#define NO_LIBINTL_OR_GETTEXT

#endif
